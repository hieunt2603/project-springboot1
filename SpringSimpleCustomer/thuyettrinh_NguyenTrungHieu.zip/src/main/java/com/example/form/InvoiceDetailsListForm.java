package com.example.form;

import lombok.Data;

@Data
public class InvoiceDetailsListForm {
	private Integer invoiceDetailsId;
	private Integer customerId;
}
