package com.example.form;

import lombok.Data;

@Data
public class CustomerListForm {
	private Integer customerId;
	private String customerName;
}
