package com.example.form;

import lombok.Data;

@Data
public class MerchandiseListForm {
	private Integer merchandiseId;
	private String merchandiseName;
}
