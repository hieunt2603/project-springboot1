package com.example.form;

public interface ValidGroup2 {

}
