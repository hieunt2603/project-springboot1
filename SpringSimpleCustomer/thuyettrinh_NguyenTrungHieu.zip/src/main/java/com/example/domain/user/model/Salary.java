package com.example.domain.user.model;

import lombok.Data;

@Data
public class Salary {
	private String userId;
	private String yearMonth;
	private String salary;
}
